<?php

// Create a PHP associative array
$data = array(
    'restart' => 0,
);

// Convert the PHP array to JSON
$jsonData = json_encode($data, JSON_PRETTY_PRINT);

// Output the JSON data
echo $jsonData;
