<?php

// Create a PHP associative array
$data = array(
    'modbus_ip' => '192.168.2.113',
    'port' => 502,
    'slave_list' => [
        1,
        2,
        3,
        4
    ],
);

// Convert the PHP array to JSON
$jsonData = json_encode($data, JSON_PRETTY_PRINT);

// Output the JSON data
echo $jsonData;

?>
